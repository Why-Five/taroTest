export default definePageConfig({
  navigationBarTitleText: '首页',
  navigationStyle: 'custom',
})
