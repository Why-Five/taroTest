export default definePageConfig({
  navigationBarTitleText: '消息详情',
})
