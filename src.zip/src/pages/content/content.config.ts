export default definePageConfig({
  navigationBarTitleText: '资源详情',
})
