export default definePageConfig({
  navigationBarTitleText: '消息列表',
})
