export default definePageConfig({
  navigationBarTitleText: '投稿页面',
})
