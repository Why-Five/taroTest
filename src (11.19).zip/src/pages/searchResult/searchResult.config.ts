export default definePageConfig({
  navigationBarTitleText: '搜索结果',
})
