export default definePageConfig({
  navigationBarTitleText: '搜索',
})
