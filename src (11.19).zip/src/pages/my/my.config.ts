export default definePageConfig({
  navigationBarTitleText: '我的',
  // 自定义头部导航栏
  navigationStyle: 'custom',
})
