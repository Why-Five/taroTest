export default definePageConfig({
  navigationBarTitleText: '我的资源',
})
