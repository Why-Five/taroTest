export default definePageConfig({
  navigationBarTitleText:'积分明细',
})
