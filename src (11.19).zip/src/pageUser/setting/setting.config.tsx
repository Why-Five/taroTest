export default definePageConfig({
  navigationBarTitleText: '设置',
})
