export default definePageConfig({
  navigationBarTitleText: '用户信息',
})
